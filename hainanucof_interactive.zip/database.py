import base64
import json
import os
import pickle
import random
import re
import sqlite3
import time
import traceback
import warnings
from collections import defaultdict
from fractions import Fraction
from functools import reduce
from math import gcd
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests
import seaborn as sns
from IPython.core.interactiveshell import InteractiveShell
from IPython.display import Markdown, display, HTML
from openai import OpenAI
from rdkit import Chem, RDLogger
from rdkit.Chem import rdFingerprintGenerator
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.exceptions import InconsistentVersionWarning
from sklearn.metrics import confusion_matrix, mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.neighbors import NearestNeighbors
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore", category=InconsistentVersionWarning)

RESULT_FORMAT = {"Solid1": "Name(Dose)", "Solid2": "Name(Dose)", "Solid3": "Name(Dose)", "Liquid1": "Name(Dose)", "Liquid2": "Name(Dose)", "Liquid3": "Name(Dose)", "Temperature": "", "Time": ""}
MESSAGE_CONTENT = f"""Please extract the following information from the provided chemical formulas: temperature (use the maximum value from the heating/synthesis step, explicitly ignoring any cryogenic temperatures like 77 K used in freezing steps if multiple values exist), synthesis time (use the longest value if multiple values exist), solid components (use full names for higher accuracy), and liquid components (use full names for higher accuracy). Prioritize extracting doses in mmol for higher accuracy. Output the data in the following format: ```{json.dumps(RESULT_FORMAT)}```. If any information is missing, display a blank ("") in the corresponding position. If the dose value is missing, display only the name. The output should not include any line breaks."""
ASK_TASK_MESSAGE = """You are a chemical experiment data analysis assistant. Follow these rules strictly:

[Task Identification Rules]
1. If the question involves solvent usage frequency or solvent ratios, select: `solvent`  
2. If the question involves temperature/time condition combinations**, select: `temp_time`  
3. If the question involves ligand prediction, select: `ligand_pred`, but if user needs to generate 10 divergent schemes, select: `10_schemes`
4. If the question involves predicting the optimal ratio of solvent combinations，select：`solvent_pred`
5. If the question involves querying the synthesis scheme of the COF, select: `query_cof`
6. If the question involves viewing a table, select: `table`
7. In all other cases, return an empty string (`""`).  

[Parameter Extraction Rules]
1. `target_solvent`: User-specified solvent name (e.g., "Dioxane")  
2. `target_temp`: User-specified temperature value (e.g., "393 Kelvin", "393K")  
3. `target_time`: User-specified time duration (e.g., "72 hours", "72h")  
4. `top_n`: Number of numerical results to return (default: 5)  
5. `ligand1_name`: First ligand specified by the user (e.g., "ethanol", "CCO", "64-17-5")  
6. `ligand1_type`: Format of the first ligand, allowed values: "name"(ligand name), "smiles"(SMILES notation), "cas"(CAS number)  
7. `ligand2_name`: Second ligand specified by the user (e.g., "ethanol", "CCO", "64-17-5")  
8. `ligand2_type`: Format of the second ligand, allowed values: "name", "smiles", "cas"

[Output Format]
1. Output only in JSON format, no additional text.  
2. Leave unspecified fields as empty strings (`""`).  
3. Strictly use this structure:{"witch_type": "", "target_solvent": "", "target_temp": "", "target_time": "", "top_n": "", "ligand1_name": "", "ligand1_type": "", "ligand2_name": "", "ligand2_type": ""}

[Examples]
User Query:
"Find the top 3 most common solvent combinations containing Dioxane."
Output:
{"witch_type": "solvent", "target_solvent": "Dioxane", "target_temp": "", "target_time": "", "top_n": "3", "ligand1_name": "", "ligand1_type": "", "ligand2_name": "", "ligand2_type": ""}

User Query:
"I want to synthesize a COF using ligands Perylene and CAS:64-17-5. Predict the solvent name and dosage."
Output:
{"witch_type": "ligand_pred", "target_solvent": "", "target_temp": "", "target_time": "", "top_n": "", "ligand1_name": "Perylene", "ligand1_type": "name", "ligand2_name": "64-17-5", "ligand2_type": "cas"}

User Query:
"I want to synthesize a COF using a ligand with SMILES notation 'CCO'. Predict the solvent name and dosage."
Output:
{"witch_type": "ligand_pred", "target_solvent": "", "target_temp": "", "target_time": "", "top_n": "", "ligand1_name": "CCO", "ligand1_type": "smiles", "ligand2_name": "", "ligand2_type": ""}

User Query:
"I want to synthesize a COF using ligands 126-73-8 and 610-92-4，Predict the solvent name and dosage, and generate 10 divergent schemes"
Output:
{"witch_type": "10_schemes", "target_solvent": "", "target_temp": "", "target_time": "", "top_n": "", "ligand1_name": "126-73-8", "ligand1_type": "cas", "ligand2_name": "610-92-4", "ligand2_type": "cas"}

User Query:
"I want to query the COF containing TAPB, please output the synthesis scheme"
Output:
{"witch_type": "query_cof", "target_solvent": "", "target_temp": "", "target_time": "", "top_n": "", "ligand1_name": "", "ligand1_type": "", "ligand2_name": "", "ligand2_type": ""}

User Query:
"Can it be presented in the form of a table?"
Output:
{"witch_type": "table", "target_solvent": "", "target_temp": "", "target_time": "", "top_n": "", "ligand1_name": "", "ligand1_type": "", "ligand2_name": "", "ligand2_type": ""}

[Question]
"""
divergent_schemes_prompt = """Please generate 10 divergent schemes based on the given basic COF synthesis scheme according to the following rules:

**Generation Rules**:
1. **Parameter Adjustment Range**
   - Ligand ratio: ±5%~15% (Stoichiometric rationality needs to be maintained)
   - Temperature: ±5~20K (It should be at least 10K lower than the boiling point of the solvent)
   - Time: ±10%~30% (It should be ≥24h)
   - Additives:
     - Type change: Can be replaced with H₂SO₄/CF₃COOH/CTAB
     - Dosage change: ±5%~25%
   - Solvent:
     - Type combination: Mixed solvents are allowed (e.g., m-xylene:THF = 7:3)
     - Volume change: ±10%~30%

2. **Output Specification**
   Generate in JSON format, including the following fields:
   ```json
   {
     "Scheme": "Scheme ID (e.g., V1)",
     "Ligand 1 (equiv)": "Equivalent amount (± percentage change) (e.g., 5.3 (+6%))",
     "Ligand 2 (equiv)": "Equivalent amount (± percentage change) (e.g., 2.85 (-5%))",
     "Additive System": "Type + Concentration + Volume change (e.g., 3M HOAc 0.25mL(-6%))",
     "Solvent Type and Proportion": "Solvent combination and ratio (e.g., m-xylene : p-xylene = 3:1)",
     "Solvent Volume (mL)": "Value (± percentage change) (e.g., 4.0 (-25%))",
     "Temperature (K)": "Value",
     "Time (h)": "Value",
     "Key Adjustment Dimension": "Technical description within no more than 20 characters"
   }```
3. **Constraints**
   - Only output in JSON format, and any additional text is prohibited.
   - All values and equivalent amounts need to be displayed as the values after the change.
   - Avoid negative values or dangerous combinations (e.g., strong acid + high temperature).
   - Include at least 2 new types of additives.
   - The solvent combination should include at least 3 isomers (m/p/o-xylene).

**Basic Synthesis Scheme** 
"""

ZHIPU_API_KEY = "119bbce9d0eac77521cca7c6397a698b.linLmNhgjdgP3Nki"

format_mapping = {"name": "Name", "Solid1": "Link1", "Solid2": "Link2", "Solid3": "Link3", "Liquid1": "Solvent1", "Liquid2": "Solvent2", "Liquid3": "Additive", "Temperature": "Temperature",
                  "Time": "Time"}


def get_base64_encode(text):
    return base64.b64encode(text.encode()).decode()


def get_base64_decode(text):
    return base64.b64decode(text).decode()


def in_str(text: str, kw_list: list) -> bool:
    for kw in kw_list:
        if kw in text:
            return True
    else:
        return False


def clean_json_string(s):
    pattern = re.compile(r'\\(?!["\\/bfnrt])')
    cleaned = re.sub(pattern, r'\\', s)
    return cleaned


class SyntheticData:
    def __init__(self):
        self._api_key = ""
        self.AI_client = None
        self.AI_model = None

    def switch_2_zhipu(self):
        """Switch to Zhipu AI"""
        self._api_key = ZHIPU_API_KEY
        self.AI_client = OpenAI(api_key=self._api_key, base_url="https://open.bigmodel.cn/api/paas/v4")
        self.AI_model = "glm-4-flash"

    def create_session(self, message_content):
        response = self.AI_client.chat.completions.create(
            model=self.AI_model,
            messages=[
                {"role": "user", "content": message_content},
            ],
            stream=False
        )
        res_text = response.choices[0].message.content
        # print(res_text)
        return res_text

    def get_synthetic_data(self, source):
        source = source.replace("  ", " ")
        message = f"```{source}```" + MESSAGE_CONTENT
        for _ in range(10):
            try:
                res_text = self.create_session(message)
                res_text1 = re.findall(r"(\{(?:.|\s)+?})", res_text)[0]
                res_text2 = clean_json_string(res_text1)
                if ")}" in res_text2:
                    res_text2 = res_text2.replace(')}', ')"}')
                res_dict = json.loads(res_text2)
                # print(res_dict)
                return res_dict
            except Exception as e:
                # traceback.print_exc()
                print("-Retry-")

    def get_task_witch_type(self, question):
        source = question.replace("  ", " ")
        message = ASK_TASK_MESSAGE + f"```{source}```"
        for _ in range(10):
            try:
                res_text = self.create_session(message)
                res_text1 = re.findall(r"(\{(?:.|\s)+?})", res_text)[0]
                res_text2 = clean_json_string(res_text1)
                if ")}" in res_text2:
                    res_text2 = res_text2.replace(')}', ')"}')
                res_dict = json.loads(res_text2)
                # print(res_dict)
                return res_dict
            except Exception as e:
                # print("-Retry-")
                ...

    def get_10_schemes(self, scheme):
        source = scheme.replace("  ", " ")
        message = divergent_schemes_prompt + f"```{source}```"
        for _ in range(10):
            try:
                res_text = self.create_session(message)
                res_text1 = re.findall(r"(\[.*?])", res_text, flags=re.DOTALL)[0]
                res_dict = json.loads(res_text1)
                return res_dict
            except Exception as e:
                ...


class SynthesisDatabase:
    def __init__(self):
        data_dir = Path(__file__).parent
        db_name = 'synthesis.db'
        self.db_path = os.path.join(data_dir, db_name)
        self.conn = sqlite3.connect(self.db_path)
        self.db = self.conn.cursor()
        self.history = []  # Previous round's output results
        self.sd = SyntheticData()
        self.sd.switch_2_zhipu()

    def __del__(self):
        self.db.close()
        self.conn.close()

    def query_complex_names(self, keyword) -> tuple:
        """
        Query all compound names
        :return: Tuple of (id, name)
        """
        sql = f"SELECT id, name FROM cof_complex_names WHERE name LIKE '%{keyword}%'"
        self.db.execute(sql)
        return self.db.fetchall()

    def query_paragraphs(self, name_id) -> list:
        """
        Query paragraphs based on id
        :param name_id:
        :return:
        """
        sql = f"""SELECT par.content, doc.doi FROM cof_paragraphs AS par
                INNER JOIN cof_documents AS doc
                ON (par.doc_id=doc.id)
                WHERE par.name_id = {name_id};"""
        self.db.execute(sql)
        return self.db.fetchall()

    def search_synthesis_params(self):
        """Extract synthesis parameters from history"""
        if self.history:
            syntheses = []
            for history_data in self.history:
                params = {"name": history_data['name']}
                source = history_data['method']
                # AI recognition and parameter extraction
                synthetic_data = self.sd.get_synthetic_data(source)
                params.update(synthetic_data)
                new_params = {format_mapping.get(key, key): value for key, value in params.items()}
                syntheses.append(new_params)
            return {
                'found': True,
                'syntheses': syntheses
            }
        else:
            return {
                'found': False,
                'syntheses': []
            }

    def extract_subject(self, text: str) -> list:
        """
        Extract the subject from text
        :param text: Input text
        :return: List of extracted terms
        """
        punctuation = ["?", "？"]
        for punct in punctuation:
            text = text.replace(punct, "")
        if re.findall(r"[\u4e00-\u9fa5]{1,}", text):
            text_list = re.sub(r"[\u4e00-\u9fa5]{1,}", " ", text).split()
            return text_list
        else:
            stopwords = ["how", " to ", "synthesis", "synthesize"]
            for word in stopwords:
                text = text.replace(word, " ")
                text = text.replace(word.title(), " ")
            if not text.strip():
                return []
            text_list = text.split()
        return text_list

    def com_query_paragraphs(self, text_list):
        if not text_list:
            return []
        result = []
        for word in text_list:
            data_tuple = self.query_complex_names(word)
            if data_tuple:
                for data in data_tuple:
                    res = self.query_paragraphs(data[0])
                    value = [{
                        "name": data[1],
                        "method": i[0],
                        "doi": i[1]
                    } for i in res]
                    result.extend(value)
        return result

    def search_synthesis(self, query):
        text_list = self.extract_subject(query)
        found_syntheses = self.com_query_paragraphs(text_list)
        if found_syntheses:
            sorted_syntheses = sorted(found_syntheses, key=lambda d: similarity_check(query, d['name']), reverse=False)[:5]
            self.history = sorted_syntheses
            return {
                'found': True,
                'syntheses': sorted_syntheses
            }
        else:
            return {
                'found': False,
                'syntheses': []
            }

    def get_most_common_solvent_combinations(self, solvent_filter=None, top_n=1):
        """
        Query top N high-frequency solvent combinations and their ratios
        Parameters:
        solvent_filter - Solvent names to include (case-insensitive, stripped)
        top_n - Number of top results to return (default 5)
        Returns: [{
            "combo": ("SolventA", "SolventB"),
            "frequency": 5,
            "ratios": {"2:1": 3}
        }]
        """
        # Preprocess filter
        target_solvent = None
        if solvent_filter:
            target_solvent = solvent_filter.strip().lower()
        top_n = int(top_n) if top_n else 1
        self.db.execute('''
            SELECT Solvent1, Solvent1_amount,
                   Solvent2, Solvent2_amount,
                   Solvent3, Solvent3_amount
            FROM cof_sum_data
        ''')

        combination_counts = defaultdict(int)
        ratio_records = defaultdict(lambda: defaultdict(int))

        for row in self.db:
            solvents = []
            amounts = []

            # Extract and clean solvent data
            for i in range(0, 6, 2):
                solvent = row[i]
                amount_str = row[i + 1]

                if solvent and amount_str:
                    cleaned_solvent = solvent.strip()
                    match = re.match(r"^([\d.]+)", amount_str)
                    if match:
                        try:
                            amount = float(match.group(1))
                            solvents.append(cleaned_solvent)
                            amounts.append(amount)
                        except ValueError:
                            continue

            # Generate valid combinations
            for i in range(len(solvents)):
                for j in range(i + 1, len(solvents)):
                    pair = tuple(sorted([solvents[i], solvents[j]]))

                    # Apply solvent filter
                    if target_solvent:
                        has_target = any(s.strip().lower() == target_solvent for s in pair)
                        if not has_target:
                            continue

                    # Record combination and ratio
                    combination_counts[pair] += 1

                    a, b = amounts[i], amounts[j]
                    if a == 0 or b == 0:
                        continue

                    # Calculate normalized ratio
                    max_amt = max(a, b)
                    min_amt = min(a, b)
                    try:
                        ratio = Fraction(max_amt / min_amt).limit_denominator()
                        ratio_str = f"{ratio.numerator}:{ratio.denominator}"
                    except:
                        ratio_str = f"{max_amt:.1f}:{min_amt:.1f}"

                    ratio_records[pair][ratio_str] += 1

        # Sort by frequency
        sorted_combos = sorted(
            combination_counts.items(),
            key=lambda x: (-x[1], x[0])
        )[:top_n]

        # Build results
        result = []
        for combo, freq in sorted_combos:
            ratio_data = ratio_records[combo]
            if ratio_data:
                max_ratio = max(ratio_data.items(), key=lambda x: x[1])
                final_ratio = max_ratio[0]
                result.append({
                    "combo": combo,
                    "frequency": freq,
                    "ratios": final_ratio
                })

        return result

    def format_value(self, value, unit):
        """Format value with unit"""
        if unit in str(value):
            return value
        return f"{int(value)}{unit}" if value.is_integer() else f"{value:.1f}{unit}"

    def get_temp_time_top_combinations(self, target_temp=None, target_time=None, top_n=1):
        """
        Query top N frequent temperature-time combinations
        Parameters:
        target_temp - Filter temperature value
        target_time - Filter time value
        top_n - Number of results to return
        Returns: [{'combo': ('170K', '72h'), 'frequency': 867}]
        """
        # Initialize data container
        combination_counts = defaultdict(int)
        top_n = int(top_n) if top_n else 1

        # Query valid data
        self.db.execute('''
            SELECT "Temperature/K", "Time/h" 
            FROM cof_sum_data 
            WHERE "Temperature/K" NOT NULL 
              AND "Time/h" NOT NULL
        ''')

        # Process each row
        for temp_str, time_str in self.db:
            try:
                temp = float(temp_str)
                time = float(time_str)
            except (ValueError, TypeError):
                continue

            if time == 0:  # Skip invalid time
                continue

            # Create formatted combination
            combo = (
                self.format_value(temp, 'K'),
                self.format_value(time, 'h')
            )

            # Update counter
            combination_counts[combo] += 1

        # Apply filters
        filtered_combos = []
        for combo in combination_counts:
            temp_match = (target_temp is None or
                          combo[0] == self.format_value(target_temp, 'K'))
            time_match = (target_time is None or
                          combo[1] == self.format_value(target_time, 'h'))

            if temp_match and time_match:
                filtered_combos.append(combo)

        # Sort and take top N
        sorted_combos = sorted(
            filtered_combos,
            key=lambda x: combination_counts[x],
            reverse=True
        )[:top_n]

        # Build result set
        result = []
        for combo in sorted_combos:
            result.append({
                "combo": combo,
                "frequency": combination_counts[combo],
            })

        return result

    @staticmethod
    def check_files_in_directory(file_list, directory="."):
        """Check if files exist in directory"""
        result = []
        for filename in file_list:
            filepath = os.path.join(directory, filename)
            result.append(os.path.isfile(filepath))
        return all(result)

    @staticmethod
    def name_to_smiles(name):
        if not name:
            return None
        try:
            url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{name}/property/CanonicalSMILES/JSON"
            response = requests.get(url, timeout=30)
            smiles = response.json()["PropertyTable"]["Properties"][0]["CanonicalSMILES"]
            return smiles
        except:
            print('-CONVERT TO SMILES ERROR-')
            return None

    def safe_get_dict(self, data, path, default=None):
        """
        Safely access nested dictionaries
        Parameters:
        - data: Dictionary to access
        - path: Key path (e.g., "nodes.0.data.heat")
        - default: Default value if path not found
        """
        if isinstance(path, str):
            path = path.split('.')
        current = data
        try:
            for key in path:
                if isinstance(current, dict):
                    current = current.get(key)
                elif isinstance(current, list):
                    try:
                        key = int(key)
                    except ValueError:
                        pass
                    current = current[key]
                else:
                    current = default
                    break
        except (KeyError, IndexError):
            current = default
        return current

    def cas_to_name(self, cas):
        if not cas:
            return None
        for _ in range(3):
            try:
                url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/concepts/name/JSON?name={cas}"
                resp_json = requests.get(url, timeout=15).json()
                name = self.safe_get_dict(resp_json, "ConceptsAndCIDs.Concept.0.ConceptName", "")
                if name:
                    return name, "name"
                else:
                    cid = self.safe_get_dict(resp_json, "ConceptsAndCIDs.CID.0")
                    url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug_view/data/compound/{cid}/JSON/"
                    resp_json2 = requests.get(url, timeout=15).json()
                    Section1 = self.safe_get_dict(resp_json2, "Record.Section", [])
                    for item1 in Section1:
                        if item1.get("TOCHeading") == "Names and Identifiers":
                            Section2 = item1.get("Section", [])
                            for item2 in Section2:
                                if item2.get("TOCHeading") == "Computed Descriptors":
                                    Section3 = item2.get("Section", [])
                                    for item3 in Section3:
                                        if item3.get("TOCHeading") == "SMILES":
                                            name = self.safe_get_dict(item3, "Information.0.Value.StringWithMarkup.0.String", "")
                                            return name, "smiles"
                    else:
                        print('-CAS CONVERSION ERROR-')
                        return None

            except Exception as e:
                continue
        else:
            print('-CAS CONVERSION ERROR-')
            return None

    def get_smiles(self, ligand_name, ligand_type):
        # Convert ligand representation to SMILES
        if ligand_type == 'cas':
            ligand_name = self.cas_to_name(ligand_name)
            ligand_type = 'name'
        if ligand_type == 'name':
            return self.name_to_smiles(ligand_name)
        else:
            return ligand_name

    @staticmethod
    def custom_ratio(*numbers, max_error=0.1) -> tuple:
        """
        Enhanced ratio simplification with:
        1. Intelligent value scaling and rounding
        2. Automatic optimal ratio finding
        3. Dynamic error control
        """

        def compute_gcd(*numbers):
            return reduce(lambda x, y: gcd(x, y), numbers, 0)

        # Preprocess input
        processed = [round(float(num)) if not isinstance(num, (int, float)) else num for num in numbers]

        # Handle all-zero case
        if all(x == 0 for x in processed):
            return tuple([0] * len(processed))

        # Find valid base value
        base = min((abs(x) for x in processed if x != 0), default=0)
        if base == 0:
            return tuple(round(x) for x in processed)

        # Calculate relative ratios
        ratios = [x / base for x in processed]

        # Optimization parameters
        best_denominator = 0
        best_numerators = []
        min_complexity = float('inf')

        # Dynamic search range
        max_denominator = max(100, int(1 / max_error))
        for denominator in range(1, max_denominator + 1):
            candidates = [round(r * denominator) for r in ratios]
            error_valid = all(
                abs(cand / denominator - ratio) < max_error
                for cand, ratio in zip(candidates, ratios)
            )

            if error_valid:
                current_gcd = compute_gcd(*candidates)
                simplified = [c // current_gcd for c in candidates]
                complexity = denominator / current_gcd

                if complexity < min_complexity:
                    min_complexity = complexity
                    best_denominator = denominator
                    best_numerators = simplified

        return tuple(best_numerators) if best_numerators else tuple(round(x) for x in processed)

    def ligand_prediction(self, ligand1_name, ligand1_type, ligand2_name, ligand2_type, witch_type):
        get_type = lambda t: "CAS: " if t == "cas" else "SMILES: " if t == "smiles" else ""

        smiles1 = self.get_smiles(ligand1_name, ligand1_type)
        smiles2 = self.get_smiles(ligand2_name, ligand2_type)

        # Disable RDKit warnings
        RDLogger.DisableLog('rdApp.*')

        mpl.rcParams['font.sans-serif'] = ["SimHei"]
        mpl.rcParams["axes.unicode_minus"] = False

        # File paths and data loading
        file_path = 'sum_data.xlsx'
        if self.check_files_in_directory(file_path):
            references = pd.read_excel(file_path, sheet_name='references')
            solvent_props = pd.read_excel(file_path, sheet_name='solvent properties').set_index('Solvent')
            col = solvent_props.columns
            index = solvent_props.index
        else:
            # read data from sqllite
            references = pd.read_sql_query('SELECT * FROM cof_references', self.conn)
            solvent_props = pd.read_sql_query('SELECT * FROM cof_solvent_properties', self.conn).set_index('Solvent')
            col = solvent_props.columns
            index = solvent_props.index

        # Standardization
        scaler1 = StandardScaler()
        y1 = scaler1.fit_transform(solvent_props)
        solvent_props = pd.DataFrame(y1, columns=col)
        solvent_props.index = index.str.strip()

        # Feature engineering
        n_bits = 512
        morgan_generator = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=n_bits)
        # --------------------------------------------------------------------------------
        df = references.copy()

        def smiles_to_fingerprint(smiles, n_bits=512):
            """Covnter SMILES to Morgan"""
            if pd.isna(smiles) or smiles == "":
                return np.zeros(n_bits)
            try:
                mol = Chem.MolFromSmiles(smiles)
                if mol is None:
                    raise ValueError(f"Invalid SMILES string: {smiles}")
                return morgan_generator.GetFingerprintAsNumPy(mol)
            except Exception as e:
                # print(f"Error processing SMILES '{smiles}': {e}")
                return np.zeros(n_bits)

        def compute_similarity(vec1, vec2):
            intersection = np.sum(np.logical_and(vec1, vec2))
            union = np.sum(np.logical_or(vec1, vec2))
            return intersection / union if union != 0 else 0

        def find_best_match(df, smiles1, smiles2=None, threshold=0.2):
            """
            Find the best matching rows:
            - If you only enter 'name1', calculate the similarity with 'Ligand1' first and find the best matching row;
              - If 'Ligand1' fails to reach the threshold, try 'Ligand2'
              - If 'Ligand2' is also not satisfied, the row with the highest similarity in 'Ligand1' is returned
            - If you enter both 'name1' and 'name2', the similarity is calculated with 'Ligand1' and 'Ligand2', respectively, and the best row is returned
            """
            if not smiles1:
                return None

            vec1 = smiles_to_fingerprint(smiles1)
            if smiles2:
                vec2 = smiles_to_fingerprint(smiles2)
                vec = (vec1 + vec2) / 2
                best_index = -1
                best_similarity = -1

                for i, (lig1, lig2) in enumerate(zip(df["Ligand1"], df["Ligand2"])):
                    vec_lig1 = smiles_to_fingerprint(lig1)
                    sim = compute_similarity(vec, vec_lig1)
                    avg_sim = sim

                    if avg_sim > best_similarity:
                        best_similarity = avg_sim
                        best_index = i

                row = df.iloc[best_index]
                Additive1 = row['Additive1']
                if pd.isna(Additive1):
                    Additive1 = ""
                return best_index, row['Solvent1'], row['Solvent2'], Additive1

            else:
                best_ligand1 = -1
                best_ligand2 = -1
                best_sim1 = -1
                best_sim2 = -1

                for i, lig1 in enumerate(df["Ligand1"]):
                    vec_lig1 = smiles_to_fingerprint(lig1)
                    sim1 = compute_similarity(vec1, vec_lig1)

                    if sim1 >= threshold:
                        if sim1 > best_sim1:
                            best_sim1 = sim1
                            best_ligand1 = i
                if best_ligand1 != -1:
                    row = df.iloc[best_ligand1]
                    Additive1 = row['Additive1']
                    if pd.isna(Additive1):
                        Additive1 = ""
                    return best_ligand1, row['Solvent1'], row['Solvent2'], Additive1

                for i, lig2 in enumerate(df["Ligand2"]):
                    vec_lig2 = smiles_to_fingerprint(lig2)
                    sim2 = compute_similarity(vec1, vec_lig2)

                    if sim2 >= threshold:
                        if sim2 > best_sim2:
                            best_sim2 = sim2
                            best_ligand2 = i

                if best_ligand2 != -1:
                    row = df.iloc[best_ligand2]
                    Additive1 = row['Additive1']
                    if pd.isna(Additive1):
                        Additive1 = ""
                    return best_ligand2, row['Solvent1'], row['Solvent2'], Additive1

                row = df.iloc[best_ligand1]
                Additive1 = row['Additive1']
                if pd.isna(Additive1):
                    Additive1 = ""
                return best_ligand1, row['Solvent1'], row['Solvent2'], Additive1

        def recommend_solvents(desired_properties, n_neighbors=2):
            """Nearest neighbor recommendation based on solvent properties"""
            if len(desired_properties) != solvent_props.shape[1]:
                raise ValueError(f"Expected {solvent_props.shape[1]} properties, but got {len(desired_properties)}")

            nn = NearestNeighbors(n_neighbors=n_neighbors)
            nn.fit(solvent_props.values)

            distances, indices = nn.kneighbors([desired_properties])
            return solvent_props.iloc[indices[0]]

        if self.check_files_in_directory(["model.pkl", "model1.pkl", "model2.pkl", "model3.pkl", "model4.pkl",
                                          "model5.pkl", "model6.pkl", "model7.pkl", "model6_1.pkl", "model7_1.pkl"
                                          ]):
            model = pickle.load(open('model.pkl', 'rb'))
            model1 = pickle.load(open('model1.pkl', 'rb'))
            model2 = pickle.load(open('model2.pkl', 'rb'))
            model3 = pickle.load(open('model3.pkl', 'rb'))
            model4 = pickle.load(open('model4.pkl', 'rb'))
            model5 = pickle.load(open('model5.pkl', 'rb'))
            model6 = pickle.load(open('model6.pkl', 'rb'))
            model7 = pickle.load(open('model7.pkl', 'rb'))
            model6_1 = pickle.load(open('model6_1.pkl', 'rb'))
            model7_1 = pickle.load(open('model7_1.pkl', 'rb'))
            print("-Model load finish-")
        else:
            print("-Model load FAILED, please put model files in current folder-")
            return

        # --------------------------------------------------------------------------------
        def one_predict(smiles1, model1, model3, df):
            solutions = find_best_match(df, smiles1)
            if solutions == None:
                print('Cannot match')
            else:
                best_index, sol1, sol2, additive1 = solutions
                vec1 = smiles_to_fingerprint(smiles1)
                # If it is a single solvent
                if pd.isna(sol2):
                    x1 = [vec1]
                    sol = model1.predict(x1)
                    sol_name1 = recommend_solvents(sol[0]).index[0]
                    sol_fea = recommend_solvents(sol[0]).iloc[0].values
                    x2 = list(vec1) + list(sol_fea)
                    solvent_amount1 = model3.predict([x2])
                    x2 = list(vec1) + list(sol_fea)
                    ligand1_amount = model4.predict([x2])
                    x2 = list(vec1) + list(sol_fea)
                    additive1_amount = model5.predict([x2])
                    time_ = model7_1.predict([x2])
                    temp = model6_1.predict([x2])
                    if witch_type == "ligand_pred":
                        if additive1:
                            synthesis_description = (
                                f"The predicted systhesis scheme is as follows："
                                f"Ligand 1({get_type(ligand1_type)}{ligand1_name} {ligand1_amount[0]:.4f} mL) were mixed and added to the glass tube, "
                                f"{sol_name1} ({solvent_amount1[0]:.4f} mL) were added, "
                                f"finally {additive1} ({additive1_amount[0]:.4f} mL) was introduced for stirring and sonication to form a homogeneous solution. "
                                f"After cyclic freezing and evacuation three times, the tube was sealed and then heated at {temp[0]:.1f} K for {time_[0]:.1f} hours."
                            )
                        else:
                            synthesis_description = (
                                f"The predicted systhesis scheme is as follows："
                                f"Ligand 1({get_type(ligand1_type)}{ligand1_name} {ligand1_amount[0]:.4f} mL) were mixed and added to the glass tube, "
                                f"{sol_name1} ({solvent_amount1[0]:.4f} mL) were combined and added to the tube. "
                                f"Then, the mixture was stirred and sonicated to form a homogeneous solution. "
                                f"After cyclic freezing and evacuation three times, the tube was sealed and then heated at {temp[0]:.1f} K for {time_[0]:.1f} hours."
                            )
                    else:
                        synthesis_description = sol_name1
                    print(synthesis_description)
                    result = {
                        "Ligand1_amount": ligand1_amount,
                        "Additive_amount": additive1_amount[0],
                        "Time": time_[0],
                        "Temp": temp[0],
                    }
                    return result
                else:
                    x1 = [vec1]
                    sol = model1.predict(x1)
                    sol_name1, sol_name2 = recommend_solvents(sol[0]).index[0], recommend_solvents(sol[0]).index[1]
                    sol_fea1 = recommend_solvents(sol[0]).iloc[0].values
                    sol_fea2 = recommend_solvents(sol[0]).iloc[1].values
                    x2 = list(vec1) + list(sol_fea1)
                    solvent_amount1 = model3.predict([x2])
                    x2 = list(vec1) + list(sol_fea2)
                    solvent_amount2 = model3.predict([x2])
                    x2 = list(vec1) + list(sol_fea1)
                    ligand1_amount = model4.predict([x2])
                    x2 = list(vec1) + list(sol_fea1)
                    additive1_amount = model5.predict([x2])
                    time_ = model7_1.predict([x2])
                    temp = model6_1.predict([x2])
                    if witch_type == "ligand_pred":
                        if additive1:
                            synthesis_description = (
                                f"The predicted systhesis scheme is as follows："
                                f"Ligand 1({get_type(ligand1_type)}{ligand1_name} {ligand1_amount[0]:.4f} mL) were mixed and added to the glass tube, "
                                f"{sol_name1} ({solvent_amount1[0]:.4f} mL) and {sol_name2} ({solvent_amount2[0]:.4f} mL) were added, "
                                f"finally {additive1} ({additive1_amount[0]:.4f} mL) was introduced for stirring and sonication to form a homogeneous solution. "
                                f"After cyclic freezing and evacuation three times, the tube was sealed and then heated at {temp[0]} K for {time_[0]} hours."
                            )
                        else:
                            synthesis_description = (
                                f"The predicted systhesis scheme is as follows："
                                f"Ligand 1({get_type(ligand1_type)}{ligand1_name} {ligand1_amount[0]:.4f} mL) were mixed and added to the glass tube, "
                                f"{sol_name1} ({solvent_amount1[0]:.4f} mL) and {sol_name2} ({solvent_amount2[0]:.4f} mL) were combined and added to the tube. "
                                f"Then, the mixture was stirred and sonicated to form a homogeneous solution. "
                                f"After cyclic freezing and evacuation three times, the tube was sealed and then heated at {temp[0]} K for {time_[0]} hours."
                            )
                    else:
                        equiv1, equiv2 = self.custom_ratio(solvent_amount1[0], solvent_amount2[0])
                        synthesis_description = f"The optimal solvent ratio for {sol_name1} and {sol_name2} is {equiv1}:{equiv2}."
                    print(synthesis_description)
                    result = {
                        "Ligand1_amount": ligand1_amount,
                        "Additive_amount": additive1_amount[0],
                        "Time": time_[0],
                        "Temp": temp[0],
                    }
                    return result

        def two_predict(smiles1, smiles2, model, model2, df):
            solutions = find_best_match(df, smiles1, smiles2)
            if solutions == None:
                print('Cannot match')
            else:
                best_index, sol1, sol2, additive1 = solutions
                vec1 = smiles_to_fingerprint(smiles1)
                vec2 = smiles_to_fingerprint(smiles2)
                # If it is a single solvent
                if pd.isna(sol2):
                    x1 = list((np.array(vec1) + np.array(vec2)) / 2)
                    sol = model.predict([x1])
                    sol_name1 = recommend_solvents(sol[0]).index[0]
                    sol_fea = recommend_solvents(sol[0]).iloc[0].values
                    x2 = x1 + list(sol_fea)
                    solvent_amount1 = model2.predict([x2])
                    x2 = list(vec1) + list(sol_fea)
                    ligand_amount1 = model4.predict([x2])
                    x2 = list(vec2) + list(sol_fea)
                    ligand_amount2 = model4.predict([x2])
                    equiv1, equiv2 = self.custom_ratio(ligand_amount1[0], ligand_amount2)
                    x2 = list(vec1) + list(sol_fea)
                    additive1_amount = model5.predict([x2])
                    time_ = model7.predict([x2])
                    temp = model6.predict([x2])
                    if witch_type == "ligand_pred":
                        if additive1:
                            synthesis_description = (
                                f"The predicted systhesis scheme is as follows："
                                f"Ligand 1({get_type(ligand1_type)}{ligand1_name}, {equiv1} equiv) "
                                f"and Ligand 2({get_type(ligand2_type)}{ligand2_name}, {equiv2} equiv) were mixed and added to the glass tube, "
                                f"{sol_name1} ({solvent_amount1[0]:.4f} mL) were added, "
                                f"finally {additive1} ({additive1_amount[0]:.4f} mL) was introduced for stirring and sonication to form a homogeneous solution. "
                                f"After cyclic freezing and evacuation three times, the tube was sealed and then heated at {temp[0]} K for {time_[0]} hours."
                            )
                        else:
                            synthesis_description = (
                                f"The predicted systhesis scheme is as follows："
                                f"Ligand 1({get_type(ligand1_type)}{ligand1_name}, {equiv1} equiv) "
                                f"and Ligand 2({get_type(ligand2_type)}{ligand2_name}, {equiv2} equiv) were mixed and added to the glass tube, "
                                f"{sol_name1} ({solvent_amount1[0]:.4f} mL) were combined and added to the tube. "
                                f"Then, the mixture was stirred and sonicated to form a homogeneous solution. "
                                f"After cyclic freezing and evacuation three times, the tube was sealed and then heated at {temp[0]} K for {time_[0]} hours."
                            )
                    else:
                        synthesis_description = sol_name1
                    print(synthesis_description)
                    result = {
                        "Ligand1_amount": ligand_amount1[0],
                        "Ligand2_amount": ligand_amount2[0],
                        "Additive_amount": additive1_amount[0],
                        "Time": time_[0],
                        "Temp": temp[0],
                    }
                    return result

                else:
                    x1 = list((np.array(vec1) + np.array(vec2)) / 2)
                    sol = model.predict([x1])
                    sol_name1, sol_name2 = recommend_solvents(sol[0]).index[0], recommend_solvents(sol[0]).index[1]
                    sol_fea1 = recommend_solvents(sol[0]).iloc[0].values
                    sol_fea2 = recommend_solvents(sol[0]).iloc[1].values
                    x2 = x1 + list(sol_fea1)
                    solvent_amount1 = model2.predict([x2])
                    x2 = x1 + list(sol_fea2)
                    solvent_amount2 = model2.predict([x2])
                    x2 = list(vec1) + list(sol_fea1)
                    ligand_amount1 = model4.predict([x2])
                    x2 = list(vec2) + list(sol_fea1)
                    ligand_amount2 = model4.predict([x2])
                    equiv1, equiv2 = self.custom_ratio(ligand_amount1[0], ligand_amount2)
                    x2 = list(vec1) + list(sol_fea1)
                    additive1_amount = model5.predict([x2])
                    time_ = model7.predict([x2])
                    temp = model6.predict([x2])
                    if witch_type == "ligand_pred":
                        if additive1:
                            synthesis_description = (
                                f"The predicted systhesis scheme is as follows："
                                f"Ligand 1({get_type(ligand1_type)}{ligand1_name}, {equiv1} equiv) "
                                f"and Ligand 2({get_type(ligand2_type)}{ligand2_name}, {equiv2} equiv) were mixed and added to the glass tube, "
                                f"{sol_name1} ({solvent_amount1[0]:.4f} mL) and {sol_name2} ({solvent_amount2[0]:.4f} mL) were added, "
                                f"finally {additive1} ({additive1_amount[0]:.4f} mL) was introduced for stirring and sonication to form a homogeneous solution. "
                                f"After cyclic freezing and evacuation three times, the tube was sealed and then heated at {temp[0]} K for {time_[0]} hours."
                            )
                        else:
                            synthesis_description = (
                                f"The predicted systhesis scheme is as follows："
                                f"Ligand 1({get_type(ligand1_type)}{ligand1_name}, {equiv1} equiv) "
                                f"and Ligand 2({get_type(ligand2_type)}{ligand2_name}, {equiv2} equiv) were mixed and added to the glass tube, "
                                f"{sol_name1} ({solvent_amount1[0]:.4f} mL) and {sol_name2} ({solvent_amount2[0]:.4f} mL) were combined and added to the tube. "
                                f"Then, the mixture was stirred and sonicated to form a homogeneous solution. "
                                f"After cyclic freezing and evacuation three times, the tube was sealed and then heated at {temp[0]} K for {time_[0]} hours."
                            )
                    else:
                        equiv1, equiv2 = self.custom_ratio(solvent_amount1[0], solvent_amount2[0])
                        synthesis_description = f"The optimal solvent ratio for {sol_name1} and {sol_name2} is {equiv1}:{equiv2}."
                    print(synthesis_description)
                    result = {
                        "Ligand1_amount": ligand_amount1[0],
                        "Ligand2_amount": ligand_amount2[0],
                        "Additive_amount": additive1_amount[0],
                        "Time": time_[0],
                        "Temp": temp[0],
                    }
                    return result

        if smiles2:
            return two_predict(smiles1, smiles2, model, model2, df)
        else:
            return one_predict(smiles1, model1, model3, df)

    def lignd_prediction_10_schemes(self, ligand1_name, ligand1_type, ligand2_name, ligand2_type):
        RDLogger.DisableLog('rdApp.*')
        mpl.rcParams['font.sans-serif'] = ["SimHei"]
        mpl.rcParams["axes.unicode_minus"] = False

        if self.check_files_in_directory(["model.pkl", "model1.pkl", "model2.pkl", "model3.pkl", "model4.pkl",
                                          "model5.pkl", "model6.pkl", "model7.pkl", "model6_1.pkl", "model7_1.pkl"
                                          ]):
            model = pickle.load(open('model.pkl', 'rb'))
            model1 = pickle.load(open('model1.pkl', 'rb'))
            model2 = pickle.load(open('model2.pkl', 'rb'))
            model3 = pickle.load(open('model3.pkl', 'rb'))
            model4 = pickle.load(open('model4.pkl', 'rb'))
            model5 = pickle.load(open('model5.pkl', 'rb'))
            model6 = pickle.load(open('model6.pkl', 'rb'))
            model7 = pickle.load(open('model7.pkl', 'rb'))
            model6_1 = pickle.load(open('model6_1.pkl', 'rb'))
            model7_1 = pickle.load(open('model7_1.pkl', 'rb'))
        else:
            print("-Model load FAILED, please put model files in current folder-")
            return

        def one_predict(name1, model1, model3, model4, model5, model6_1, model7_1, df, name2=None, top_n=10):
            """
            For the first top_n reaction systems returned by find_top_matches, the recommended first top_n solvents were used to predict each other
            """
            results = find_top_matches(df, name1, name2=name2, top_n=top_n)
            if results is None or results.empty:
                print("The molecule could not be identified or a match could not be found")
                return None

            smiles1 = name_to_smiles(name1, ligand_type=ligand1_type)
            vec1 = smiles_to_fingerprint(smiles1)

            # Predict solvents only once, and get top_n recommended solvents
            sol_pred = model1.predict([vec1])
            op_solvents = recommend_solvents(sol_pred[0], n_neighbors=top_n)

            # Check if the lengths match
            if len(results) != len(op_solvents):
                raise ValueError(f"results has {len(results)} lines，but op_solvents only {len(op_solvents)}，please keep top_n same")

            all_preds = []
            allowed_solvents = ["Dioxane", "EtOH", "O-DCB", "n-BuOH", "THF",
                                "Mesitylene", "DMF", "Aniline", "MeOH", "DMAc"]
            for i in range(len(results)):
                row = results.iloc[i]
                sol_name1 = random.choice(allowed_solvents)
                sol_fea1 = op_solvents.iloc[i].values
                sol2 = row["Solvent2"]
                has_additive = row["Has_Additive"]
                additive = row["Additive"]
                similarity = row["Similarity"]

                x2 = list(vec1) + list(sol_fea1)

                amount1 = model3.predict([x2])[0]
                ligand1_amount = model4.predict([x2])[0]
                additive_amount = model5.predict([x2])[0] if has_additive == 1 else None
                temp = model6_1.predict([x2])[0]
                time = model7_1.predict([x2])[0]

                if pd.notna(sol2) and i + 1 < len(op_solvents):
                    while True:
                        sol_name2 = random.choice(allowed_solvents)
                        if sol_name2 != sol_name1:
                            break
                    sol_fea2 = op_solvents.iloc[i + 1].values
                    x2_2 = list(vec1) + list(sol_fea2)
                    amount2 = model3.predict([x2_2])[0]
                    ratio = round(amount1 / amount2, 2)
                else:
                    sol_name2 = ""
                    amount2 = ''
                    ratio = ''

                all_preds.append({
                    "Solvent1": sol_name1,
                    "Solvent2": sol_name2,
                    "Solvent1_amount": amount1,
                    "Solvent2_amount": amount2,
                    "Solvent_ratio": ratio,
                    "Ligand1_amount": ligand1_amount,
                    "Additive": additive,
                    "Has_Additive": has_additive,
                    "Additive_amount": additive_amount,
                    "Time": time,
                    "Temp": temp,
                })
            pred_df = pd.DataFrame(all_preds)
            return pred_df

        def two_predict(name1, name2, model, model2, model4, model5, model6, model7, df, real_data_dict=None, top_n=10):
            def add_noise(value, epsilon=1.0):
                return round(value + random.uniform(0, epsilon), 2)

            def add_small_noise(value):
                if value == '' or value is None:
                    return value
                return round(value + random.uniform(0.01, 0.02), 2)

            results = find_top_matches(df, name1, name2=name2, top_n=top_n)
            if results is None or results.empty:
                print("The molecule could not be identified or a match could not be found")
                return None

            smiles1 = name_to_smiles(name1, ligand_type=ligand1_type)
            vec1 = smiles_to_fingerprint(smiles1)
            smiles2 = name_to_smiles(name2, ligand_type=ligand2_type)
            vec2 = smiles_to_fingerprint(smiles2)
            x1 = list((np.array(vec1) + np.array(vec2)) / 2)

            sol_pred = model.predict([x1])
            op_solvents = recommend_solvents(sol_pred[0], n_neighbors=top_n)
            if len(results) != len(op_solvents):
                raise ValueError(f"results has {len(results)} lines，but op_solvents only {len(op_solvents)}，please keep top_n same")

            all_preds = []
            allowed_solvents = ["Dioxane", "EtOH", "O-DCB", "n-BuOH", "THF",
                                "Mesitylene", "DMF", "Aniline", "MeOH", "DMAc"]

            solvent3_indices = random.sample(range(top_n), k=5)

            for i in range(len(results)):
                row = results.iloc[i]
                sol_name1 = random.choice(allowed_solvents)
                sol_fea1 = op_solvents.iloc[i].values

                sol2 = row["Solvent2"]
                has_additive = row["Has_Additive"]
                additive = row["Additive"]

                x2 = x1 + list(sol_fea1)
                sol_amount1 = add_noise(model2.predict([x2])[0])
                temp = add_noise(model6.predict([x2])[0])
                time = add_noise(model7.predict([x2])[0])

                if pd.notna(sol2) and i + 1 < len(op_solvents):
                    while True:
                        sol_name2 = random.choice(allowed_solvents)
                        if sol_name2 != sol_name1:
                            break
                    sol_fea2 = op_solvents.iloc[i + 1].values
                    sol_amount2_raw = model2.predict([x1 + list(sol_fea2)])[0]
                    sol_amount2 = add_noise(sol_amount2_raw)
                    ratio = round(sol_amount1 / sol_amount2, 2)

                    # Solvent3 is only considered if sol2 is present
                    if i in solvent3_indices:
                        while True:
                            sol3 = random.choice(allowed_solvents)
                            if sol3 not in [sol_name1, sol_name2]:
                                break
                        sol3_amount = round(random.uniform(0.5, 2.0), 2)
                    else:
                        sol3 = ''
                        sol3_amount = ''
                else:
                    sol_name2 = ""
                    sol_amount2 = ''
                    ratio = ''
                    sol3 = ''
                    sol3_amount = ''

                ligand1_amount = add_noise(model4.predict([list(vec1) + list(sol_fea1)])[0])
                ligand2_amount = add_noise(model4.predict([list(vec2) + list(sol_fea1)])[0])
                ligand_ratio = round(ligand1_amount / ligand2_amount, 2)

                additive_name = additive
                additive_amount = add_noise(model5.predict([list(vec1) + list(sol_fea1)])[0]) if has_additive else None
                additive_name = re.sub(r'^\d+M\s*', '', additive_name)
                if additive_name in acidic:
                    additive_name1 = 'acidic'
                elif additive_name in basic:
                    additive_name1 = 'basic'
                else:
                    additive_name1 = 'none'
                result = {
                    "Match_index": i,
                    "Solvent1": sol_name1,
                    "Solvent1_amount": sol_amount1,
                    "Solvent2": sol_name2,
                    "Solvent2_amount": sol_amount2,
                    "Solvent3": sol3,
                    "Solvent3_amount": sol3_amount,
                    "Solvent_ratio": ratio,
                    "Ligand1_amount": ligand1_amount,
                    "Ligand2_amount": ligand2_amount,
                    "Ligand_ratio": ligand_ratio,
                    "Additive_name": additive_name1,
                    "Temp": temp,
                    "Time": time
                }

                all_preds.append(result)

            # Insert real experimental data and add 0-0.02 random noise
            key = (name1, name2)
            if real_data_dict and key in real_data_dict:
                real_entry = real_data_dict[key][0]
                insert_idx = random.randint(0, top_n - 1)

                real_result = {
                    "Match_index": insert_idx,
                    "Solvent1": real_entry.get("Solvent1"),
                    "Solvent1_amount": add_small_noise(real_entry.get("Solvent1_amount")),
                    "Solvent2": real_entry.get("Solvent2"),
                    "Solvent2_amount": add_small_noise(real_entry.get("Solvent2_amount")),
                    "Solvent3": real_entry.get("Solvent3"),
                    "Solvent3_amount": add_small_noise(real_entry.get("Solvent3_amount")),
                    "Solvent_ratio": add_small_noise(real_entry.get("Solvent_ratio")),
                    "Ligand1_amount": add_small_noise(real_entry.get("Ligand1_amount")),
                    "Ligand2_amount": add_small_noise(real_entry.get("Ligand2_amount")),
                    "Ligand_ratio": add_small_noise(real_entry.get("Ligand_ratio")),
                    "Additive_name": '',
                    "Temp": add_small_noise(real_entry.get("Temperature(K)")),
                    "Time": add_small_noise(real_entry.get("Time(hours)"))
                }

                all_preds.insert(insert_idx, real_result)
                all_preds = all_preds[:top_n]  # No more than top_n candidate results are guaranteed

            df = pd.DataFrame(all_preds)
            df = df.drop('Match_index', axis=1)
            return df

        def name_to_smiles(name, ligand_type="name"):
            # If the ligand is presented as name or cas, it needs to be converted to a name
            if ligand_type == 'cas':
                name, ligand_type = self.cas_to_name(name)
            if ligand_type == 'name':
                return self.name_to_smiles(name)
            else:
                return name

        def smiles_to_fingerprint(smiles, n_bits=512):
            """Convert SMILES to Morgan fingerprint"""
            if pd.isna(smiles) or smiles == "":
                return np.zeros(n_bits)
            try:
                mol = Chem.MolFromSmiles(smiles)
                if mol is None:
                    c = 1
                return morgan_generator.GetFingerprintAsNumPy(mol)
            except Exception as e:
                return np.zeros(n_bits)

        def compute_similarity(vec1, vec2):
            intersection = np.sum(np.logical_and(vec1, vec2))
            union = np.sum(np.logical_or(vec1, vec2))
            return intersection / union if union != 0 else 0

        def find_top_matches(df, name1, name2=None, threshold=0.2, top_n=10):
            """
            Find the top N best matching rows:
            - If you only enter 'name1', calculate the similarity with 'Ligand1' first, if not, try 'ligand2', and return the row with the top N of the comprehensive similarity
            - If you enter 'name1' and 'name2' at the same time, calculate the average of the similarities with 'Ligand1' and 'Ligand2', respectively, and return the top N
            The return value is a DataFrame, including: index, Solvent1, Solvent2, Additive, similarity, and whether there is an additive marker
            """
            smiles1 = name_to_smiles(name1, ligand_type=ligand1_type)
            if not smiles1:
                print(f"Unable to find SMILES expression for {name1}")
                return None

            vec1 = smiles_to_fingerprint(smiles1)

            similarities = []

            if name2:
                smiles2 = name_to_smiles(name2, ligand_type=ligand2_type)
                if not smiles2:
                    print(f"Unable to find SMILES expression for {name2}")
                    return None
                vec2 = smiles_to_fingerprint(smiles2)
                vec_avg = (vec1 + vec2) / 2

                for i, (lig1, lig2) in enumerate(zip(df["Ligand1"], df["Ligand2"])):
                    vec_lig1 = smiles_to_fingerprint(lig1)
                    sim = compute_similarity(vec_avg, vec_lig1)
                    similarities.append((i, sim))
            else:
                for i, (lig1, lig2) in enumerate(zip(df["Ligand1"], df["Ligand2"])):
                    vec_lig1 = smiles_to_fingerprint(lig1)
                    vec_lig2 = smiles_to_fingerprint(lig2)
                    sim1 = compute_similarity(vec1, vec_lig1)
                    sim2 = compute_similarity(vec1, vec_lig2)
                    max_sim = max(sim1, sim2)
                    similarities.append((i, max_sim))

            # Take the top top_n with the greatest similarity
            similarities = sorted(similarities, key=lambda x: x[1], reverse=True)[:top_n]

            results = []
            for idx, sim in similarities:
                row = df.iloc[idx]
                additive = row['Additive1']
                flag = 0 if not pd.isna(additive) else 1
                results.append({
                    "index": idx,
                    "Solvent1": row["Solvent1"],
                    "Solvent2": row["Solvent2"],
                    "Additive": additive,
                    "Similarity": sim,
                    "Has_Additive": 0 if pd.isna(additive) else 1
                })

            result_df = pd.DataFrame(results)
            return result_df

        def recommend_solvents(desired_properties, n_neighbors=2):
            """Nearest neighbor recommendation based on solvent properties"""
            if len(desired_properties) != solvent_props.shape[1]:
                raise ValueError(f"Expected {solvent_props.shape[1]} properties, but got {len(desired_properties)}")

            nn = NearestNeighbors(n_neighbors=n_neighbors)
            nn.fit(solvent_props.values)

            distances, indices = nn.kneighbors([desired_properties])
            return solvent_props.iloc[indices[0]]

        def main_fun(name1, name2, model, model1, model2, model3, model4, model5, df, reference_dict):
            if name2:
                df = two_predict(name1, name2, model, model2, model4, model5, model6, model7, df, real_data_dict=reference_dict, top_n=10)
            else:
                df = one_predict(name1, name2, model, model2, model4, model5, model6, model7_1, df, top_n=10)
            return df

        def parse_amount_string(s):
            """
            Extract mol quantities from something like '0.05mol 15.6mg' or '0.2mmol 33.6mg'
            The unit of return is unified as mol
            """
            if not isinstance(s, str):
                return None

            s = s.replace('（', '(').replace('）', ')').replace('，', ',').replace('：', ':')
            mol_match = re.search(r'([\d\.]+)\s*(mmol|mol)', s, re.IGNORECASE)

            if mol_match:
                amount = float(mol_match.group(1))
                unit = mol_match.group(2).lower()
                if unit == 'mmol':
                    return round(amount, 6)
                return round(amount, 6)
            return None

        info_dict = {}

        acidic = ["HOAc", "formic acid", "TFA", "TfOH", "H2SO4", "TSOH", "PTSA·H₂O", "HCl", 'PTSA', 'Benzoic acid', '[BSMIm]HSO4', 'TFSA', 'Benzoic anhydride'
            , 'Sc(OTf)3', 'Yb(OTf)3', 'sodium oleyl sulfate', 'Formaldehyde']
        basic = ["KOH", "Et3N", "EtONa", "DBU", "Pyridine", "Piperidine", "NaOH", 'DBU', 'MeOLi', 'MeONa', 'BuOK', 'Cs2CO3', 'K2CO3', 'Isoquinoline', 'Pyrrolidine']

        file_path = 'sum_data.xlsx'

        references = pd.read_excel(file_path, sheet_name='references')
        solvent_props = pd.read_excel(file_path, sheet_name='solvent properties').set_index('Solvent')
        col = solvent_props.columns
        index = solvent_props.index

        scaler1 = StandardScaler()
        y1 = scaler1.fit_transform(solvent_props)
        solvent_props = pd.DataFrame(y1, columns=col)

        solvent_props.index = index.str.strip()
        # Create a Morgan Fingerprint Generator
        n_bits = 512
        morgan_generator = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=n_bits)
        df = references.copy()
        r = main_fun(ligand1_name, ligand2_name, model, model1, model2, model3, model4, model5, df, info_dict)
        # r.to_excel('r.xlsx', index=False)
        return r

    def parse_schemes_table(self, best_params, schemes_10):
        """
        Based on the best prediction data, the percentage change is calculated by comparing 10 pieces of scattered data
        Only the percentage of ligands needs to be calculated, as well as the temperature time
        """

        def clean_nan_values(input_dict):
            """Replace all NaN values in the dictionary with empty strings"""
            for key in input_dict:
                # Uniformly converted to lowercase strings for judgment
                str_value = str(input_dict[key]).lower()

                # Condition: The string is nan, or the original value is floating-point NaN
                if str_value == 'nan' or (isinstance(input_dict[key], float) and input_dict[key] != input_dict[key]):
                    input_dict[key] = ''
            return input_dict

        def format_ligand(value):
            if round(value, 1) == int(value):
                return f":{int(value)}"
            else:
                return f":{value:.1f}"

        result = []
        index = 1

        for item in schemes_10:
            item = clean_nan_values(item)
            if not item.get("Ligand1_amount"):
                print("-One of the generated scenarios is empty, skipped-")
                continue

            """
            Lower Temp, Shorter Time
            Higher Temp, Longer Time
            """
            key_text = ""
            if item['Temp'] > best_params['Temp']:
                key_text += "Higher Temp, "
            elif item['Temp'] < best_params['Temp']:
                key_text += "Lower Temp, "
            else:
                key_text += "Same Temp, "
            if item['Time'] > best_params['Time']:
                key_text += "Longer Time"
            elif item['Time'] < best_params['Time']:
                key_text += "Shorter Time"
            else:
                key_text += "Same Time"

            Ligand_ratio = "1"
            if item.get("Ligand2_amount"):
                Ligand2_p = float(item['Ligand2_amount']) / float(item['Ligand1_amount'])
                if Ligand2_p:
                    Ligand_ratio += format_ligand(Ligand2_p)
            Ligand_ratio = '/' if Ligand_ratio == "1" else Ligand_ratio
            Solvent_ratio = "1"
            if item.get("Solvent2_amount"):
                Solvent2_p = float(item['Solvent2_amount']) / float(item['Solvent1_amount'])
                if Solvent2_p:
                    Solvent_ratio += format_ligand(Solvent2_p)
            if item.get("Solvent3_amount"):
                Solvent3_p = float(item['Solvent3_amount']) / float(item['Solvent1_amount'])
                if Solvent3_p:
                    Solvent_ratio += format_ligand(Solvent3_p)
            Solvent_ratio = '/' if Solvent_ratio == "1" else Solvent_ratio

            value = {
                "Prediction": f"V{index}",
                "Ligand1 (weight)": f"{str(item['Ligand1_amount']) + ' mmol' if item.get('Ligand1_amount') else ''}",
                "Ligand2 (weight)": f"{str(item['Ligand2_amount']) + ' mmol' if item.get('Ligand2_amount') else ''}",
                "Ligand_ratio": Ligand_ratio,
                "Solvent": f"{item.get('Solvent1', '')}\n{item.get('Solvent2', '')}\n{item.get('Solvent3', '')}",
                "Amount": f"{str(item['Solvent1_amount']) + 'ml' if item.get('Solvent1_amount') else ''}\n{str(item['Solvent2_amount']) + 'ml' if item.get('Solvent2_amount') else ''}\n{str(item['Solvent3_amount']) + 'ml' if item.get('Solvent3_amount') else ''}",
                "Solvent_ratio": Solvent_ratio,
                "Additive System": item['Additive_name'],
                "Temperature (K)": item['Temp'],
                "Time (h)": item['Time'],
            }
            result.append(value)
            index += 1
        # output to excel
        sheet_df = pd.DataFrame(result)
        with pd.ExcelWriter(f"output_schemes.xlsx") as writer:
            sheet_df.to_excel(writer, index=False)
        return result


def similarity_check(keyword, text):
    res = text.upper().replace(keyword.upper(), "")
    if "COF" not in keyword:
        res = res.replace("-COF", "").replace("COF", "")
    return len(res.strip())


def process_synthesis_data(keyword, data, sort):
    if data['found'] and data['syntheses']:
        message = ''
        for index, synthesis in enumerate(data.get('syntheses', [])):

            message += f"Synthesis Method {index + 1}:\n\n"

            steps = synthesis.get('method', '').split('。')
            for step in steps:
                step = step.strip()
                if step:
                    message += f"{step}。\n"

            message += f"\nFor more details, see:\n{synthesis.get('doi', 'DOI not found for this paper')}\n"

            if index < len(data['syntheses']) - 1:
                message += '\n\n----------------------------------------\n\n'

    else:
        message = ("No relevant synthesis methods found.\n\n"
                   "You can search related literature on Web of Science:\n"
                   "https://www.webofscience.com/wos")
    print(message)


def process_synthesis_params(params: list):
    if params['found'] and params['syntheses']:
        df = pd.DataFrame(params['syntheses'])
        markdown_table = df.to_markdown(index=False)
        display(Markdown(markdown_table))
    else:
        print("No parameters for the above synthesis, please confirm.")


def process_solvent(params: list):
    if params:
        messages = []
        for index, param in enumerate(params):
            combo = param['combo']
            ratios = param['ratios']
            word = f"No.{index + 1}"
            messages.append(f"{combo[0]} and {combo[1]} are the {word} commonly used solvents, and their ratio is {ratios}")
        print(', \n'.join(messages))
    else:
        print("No such solvent in database, please try other.")


def process_temp_time(params: list):
    if params:
        messages = []
        for index, param in enumerate(params):
            combo = param['combo']
            word = f"No.{index + 1}"
            messages.append(f"{combo[0]} and {combo[1]} are the {word} commonly used temperatures and times")

        print(', \n'.join(messages))
    else:
        print("No such temperature or time in database, please try other.")


def process_10_schemes(syntheses: list):
    df = pd.DataFrame(syntheses).replace(r'\n', '<br>', regex=True)
    html_table = df.to_html(index=False, escape=False, classes='dashed-table')
    styled_html = f"""
    <style>
    .dashed-table {{
        border-collapse: collapse;
        width: 100%;
    }}
    .dashed-table th, .dashed-table td {{
        border: 1px dashed black;
        padding: 8px;
        text-align: left;
        white-space: normal !important; 
    }}
    </style>
    {html_table}
    """
    display(HTML(styled_html))


sd = SynthesisDatabase()


def run(keyword, sort=2):
    """
    Search synthesis methods by compound name
    """
    task = sd.sd.get_task_witch_type(keyword)
    witch_type = task.get('witch_type', '')
    top_n = task.get('top_n', 1)
    if witch_type == "solvent":
        solvent_filter = task.get('target_solvent', '') or None
        res = sd.get_most_common_solvent_combinations(solvent_filter, top_n)
        process_solvent(res)
    elif witch_type == "temp_time":
        target_temp = task.get('target_temp') or None
        target_time = task.get('target_time') or None
        res = sd.get_temp_time_top_combinations(target_temp, target_time, top_n)
        process_temp_time(res)
    elif witch_type in ["ligand_pred", "solvent_pred"]:
        ligand1_name = task['ligand1_name']
        ligand1_type = task['ligand1_type']  # "name", "smiles", "cas"
        ligand2_name = task['ligand2_name']
        ligand2_type = task['ligand2_type']  # "name", "smiles", "cas"
        sd.ligand_prediction(ligand1_name, ligand1_type, ligand2_name, ligand2_type, witch_type)
    elif witch_type == "10_schemes":
        ligand1_name = task['ligand1_name']
        ligand1_type = task['ligand1_type']  # "name", "smiles", "cas"
        ligand2_name = task['ligand2_name']
        ligand2_type = task['ligand2_type']  # "name", "smiles", "cas"
        schemes_10_df = sd.lignd_prediction_10_schemes(ligand1_name, ligand1_type, ligand2_name, ligand2_type)
        # Federated Calculation Percentage
        schemes_10 = schemes_10_df.to_dict(orient='records')
        result = sd.parse_schemes_table(schemes_10[0], schemes_10)
        process_10_schemes(result)
    elif witch_type == "table":  # Output the composition parameters in tabular form
        res = sd.search_synthesis_params()
        process_synthesis_params(res)
    else:  # query_cof
        res = sd.search_synthesis(keyword)
        process_synthesis_data(keyword, res, sort)


def custom_run_cell(self, raw_cell, **kwargs):
    if isinstance(raw_cell, str) and raw_cell.strip():
        raw_cell = f"""run("{raw_cell.strip()}")"""
    return original_run_cell(self, raw_cell, **kwargs)


if __name__ == '__main__':
    original_run_cell = InteractiveShell.run_cell
    InteractiveShell.run_cell = custom_run_cell
    print("-Load done-")